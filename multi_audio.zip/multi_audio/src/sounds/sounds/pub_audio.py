import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class AudioPublisher(Node):
    def __init__(self):
        super().__init__('audio_publisher')
        self.publisher_ = self.create_publisher(String, 'audio_request', 10)
        self.available_songs = ["A_D.wav", "L_B.wav", "S_C.wav", "P_n_G.wav", "W.wav", "W-P.wav"]
        self.timer = self.create_timer(5.0, self.publish_random_song)  # Publish every 10 sec

    def publish_random_song(self):
        song_name = random.choice(self.available_songs)  # Pick one song randomly
        msg = String()
        msg.data = song_name  # Send only the song name
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published song request: {song_name}')

def main(args=None):
    rclpy.init(args=args)
    node = AudioPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

