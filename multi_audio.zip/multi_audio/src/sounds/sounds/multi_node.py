def main():
    print('Hi from sounds.')


if __name__ == '__main__':
    main()
