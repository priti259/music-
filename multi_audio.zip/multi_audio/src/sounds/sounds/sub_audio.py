import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from playsound import playsound
from ament_index_python.packages import get_package_share_directory
import os

class AudioPlayerNode(Node):
    def __init__(self):
        super().__init__('audio_subscriber')
        self.subscription = self.create_subscription(
            String, 'audio_request', self.play_requested_song, 10)
        self.package_share_directory = get_package_share_directory('sounds')

    def play_requested_song(self, msg):
        audio_file = msg.data.strip()  # Expect only a file name
        audio_path = os.path.join(self.package_share_directory, 'resource', audio_file)

        if not os.path.isfile(audio_path):
            self.get_logger().error(f'Audio file not found: {audio_path}')
            return

        self.get_logger().info(f'Playing audio: {audio_file}')
        try:
            playsound(audio_path)
            self.get_logger().info(f'Finished playing: {audio_file}')
        except Exception as e:
            self.get_logger().error(f'Error playing {audio_file}: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = AudioPlayerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

