from setuptools import find_packages, setup

package_name = 'sounds'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/multi_launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='harsh2503',
    maintainer_email='harsh2503@todo.todo',
    description='ROS2 Audio Playback Package',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'audio_publisher = sounds.pub_audio:main',  # Correct module and script name
            'audio_subscriber = sounds.sub_audio:main',  # Correct module and script name
        ],
    },
)

