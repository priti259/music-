import launch
import launch_ros.actions

def generate_launch_description():
    return launch.LaunchDescription([
        launch_ros.actions.Node(
            package='sounds',
            executable='audio_publisher',
            name='audio_publisher',
            output='screen'
        ),
        launch_ros.actions.Node(
            package='sounds',
            executable='audio_subscriber',
            name='audio_subscriber',
            output='screen'
        )
    ])
